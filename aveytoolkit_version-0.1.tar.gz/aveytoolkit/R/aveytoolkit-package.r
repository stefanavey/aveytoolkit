#' aveytoolkit.
#'
#' @name aveytoolkit
#' @docType package
NULL
